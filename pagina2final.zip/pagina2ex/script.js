const searchInput = document.getElementById("pesquisa-input");
const searchIcon = document.getElementById("icone");


// mostrar barra
searchIcon.addEventListener("mouseover", function() {
  searchInput.style.display = "block";
  searchInput.focus();
}); 

// esconder barra
searchInput.addEventListener("mouseleave", function(event) {
    searchInput.style.display = "none";
  }
);

// esconder barra de input
searchInput.addEventListener("keydown", function(event) {
  if (event.key === "Enter") {
    console.log("Pesquisa: " + searchInput.value);
  }
});


// =============================== Slider ===========================================

let slides = document.querySelectorAll('.slide');
let currentSlide = 0; 
let prev = document.getElementById('prev'); 
let next = document.getElementById('next'); 

function showSlide(n) {
  slides[currentSlide].classList.remove('active'); // remove "active" do slide
  currentSlide = (n + slides.length) % slides.length; // calcula o índice do proximo slide
  slides[currentSlide].classList.add('active'); // adiciona a classe "active" pro proximo
}

function nextSlide() {
  showSlide(currentSlide + 1); // chama a função showSlide para exibir o proximo slide
}

function previousSlide() {
  showSlide(currentSlide - 1); // chama a função showSlide para exibir o slide anterior
}

prev.addEventListener('click', previousSlide); 
next.addEventListener('click', nextSlide); 

showSlide(currentSlide); 



