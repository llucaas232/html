// =============================== Dados ===========================================


  // ======================= 2019 =========================== //

fetch('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
  .then(res => res.json())
  .then(data => {
    const body = document.querySelector("#table_body2019");

    data.data.forEach(country => {
      let year = parseInt(country['Year']);
      if ("2019".includes(country['Year'])) {
        const tr = document.createElement('tr');
        const tdCountry = document.createElement('td');
        const tdPopulation = document.createElement('td');
        tdCountry.textContent = country['Nation'];
        tdPopulation.textContent = country['Population'];
        body.appendChild(tr);
        tr.appendChild(tdCountry);
        tr.appendChild(tdPopulation);

        const source = data.source[0];
        const tdSource = document.createElement('td');
        tdSource.textContent = source.annotations.source_name;
        tr.appendChild(tdSource);
      }
    });
  });


  // ======================= 2018 =========================== //

  fetch('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
  .then(res => res.json())
  .then(data => {
    const body = document.querySelector("#table_body2018");

    data.data.forEach(country => {
      let year = parseInt(country['Year']);
      if ("2018".includes(country['Year'])) {
        const tr = document.createElement('tr');
        const tdCountry = document.createElement('td');
        const tdPopulation = document.createElement('td');
        tdCountry.textContent = country['Nation'];
        tdPopulation.textContent = country['Population'];
        body.appendChild(tr);
        tr.appendChild(tdCountry);
        tr.appendChild(tdPopulation);

        const source = data.source[0];
        const tdSource = document.createElement('td');
        tdSource.textContent = source.annotations.source_name;
        tr.appendChild(tdSource);
      }
    });
  });

  // ======================= 2017 =========================== //

  fetch('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
  .then(res => res.json())
  .then(data => {
    const body = document.querySelector("#table_body2017");

    data.data.forEach(country => {
      let year = parseInt(country['Year']);
      if ("2017".includes(country['Year'])) {
        const tr = document.createElement('tr');
        const tdCountry = document.createElement('td');
        const tdPopulation = document.createElement('td');
        tdCountry.textContent = country['Nation'];
        tdPopulation.textContent = country['Population'];
        body.appendChild(tr);
        tr.appendChild(tdCountry);
        tr.appendChild(tdPopulation);

        const source = data.source[0];
        const tdSource = document.createElement('td');
        tdSource.textContent = source.annotations.source_name;
        tr.appendChild(tdSource);
      }
    });
  });

  // ======================= 2016 =========================== //

  fetch('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
  .then(res => res.json())
  .then(data => {
    const body = document.querySelector("#table_body2016");

    data.data.forEach(country => {
      let year = parseInt(country['Year']);
      if ("2016".includes(country['Year'])) {
        const tr = document.createElement('tr');
        const tdCountry = document.createElement('td');
        const tdPopulation = document.createElement('td');
        tdCountry.textContent = country['Nation'];
        tdPopulation.textContent = country['Population'];
        body.appendChild(tr);
        tr.appendChild(tdCountry);
        tr.appendChild(tdPopulation);

        const source = data.source[0];
        const tdSource = document.createElement('td');
        tdSource.textContent = source.annotations.source_name;
        tr.appendChild(tdSource);
      }
    });
  });
 

// =============================== Crescente ===========================================



function Ascending() {
  const rows = document.querySelector('.rows');
  const sortedBars = Array.from(rows.children)
      .sort((a, b) => {
          const yearA = parseInt(a.querySelector('label').textContent);
          const yearB = parseInt(b.querySelector('label').textContent);
          return yearA - yearB;
      })
      .map(bar => rows.removeChild(bar));
  
  sortedBars.forEach(bar => {
      rows.appendChild(bar);
  });
}


// =============================== Decrescente ===========================================

function Descending() {
  const rows = document.querySelector('.rows');
  const sortedBars = Array.from(rows.children)
      .sort((a, b) => {
          const yearA = parseInt(a.querySelector('label').textContent);
          const yearB = parseInt(b.querySelector('label').textContent);
          return yearB - yearA;
      })
      .map(bar => rows.removeChild(bar));
  
  sortedBars.forEach(bar => {
      rows.appendChild(bar);
  });
}


const ascButton = document.getElementById('ascending');
ascButton.addEventListener('click', sortBarsAsc);

const descButton = document.getElementById('descending');
descButton.addEventListener('click', sortBarsDesc);

